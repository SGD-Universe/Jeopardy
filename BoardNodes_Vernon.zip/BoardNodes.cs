using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class BoardNodes : MonoBehaviour
{
    // camPos is where the camera is positioned when viewing selected question. To set up in game, move viewport to desiered position, align main camera to view, create empty game object, clear game object's transform values, copy & paste camera's transform component values into game object, child game object to question in hierarchy, and drag game object into camPos slot.
    // reachableNodes is the list of questions/category titles adjacent to selected question. Click & drag adjacent nodes from hierarchy into list whilst using inspector.
    // nodeCol is used to select questions/category titles. If question/category title(s) do not have collider component, add box collider and scale to object.
    public Transform camPos;
    public List<BoardNodes> reachableNodes = new List<BoardNodes>();
    [HideInInspector]
    public Collider nodeCol;

    // Start is called before the first frame update
    void Start()
    {
        nodeCol = GetComponent<Collider>();
    }
    private void OnMouseDown()
    {
        Arrive();
    }
    void Arrive ()
    {
        if (GameManager.ins.currentNode! = null)
        {
            GameManager.ins.currentNode.Leave();
        }
        GameManager.ins.currentNode = this;
        Camera.main.transform.position = camPos.position;
        Camera.main.transform.rotation = camPos.rotation;
        //turn off this collider
        if (nodeCol != null)
        { 
            nodeCol.enabled = false;
        }
        //turn on adjacent colliders
        foreach (Node BoardNodes in reachableNodes )
        {
            if (BoardNodes.nodeCol  != null)
            {
                BoardNodes.nodeCol.enabled = true;
            }
        }
    }
    public void Depart()
    {
        foreach (Node BoardNodes in reachableNodes)
        {
            if (BoardNodes.nodeCol != null)
            {
                BoardNodes.nodeCol.enabled = false;
            }
        }
    }
    // Cut and paste following into game manager script; do not copy repeditive variables or classes.
    public static GameManager ins;
    public Node currentNode;
    private void Awake()
    {
        ins = this;
    }
}
